# Done by: Namir and ibrahim
import turtle as t #Importing the turtle

window = t.Screen()  # Create the screen object
square = t.Turtle()  # Create a turtle object to draw shapes
t.tracer(False)   

""" MAIN LOOP TO INTERACT WITH THE USER """

# Starting a loop to keep the program running until the user exits
while True:
    # Asking the user to input which drawing they want to see
    user_input = input(
        "Which drawing do you want to be shown? \n- Star \n- Yoda \n- Mario \n- Luigi \n"
        "Or, you can choose to exit by typing, 'exit'. \n- ").lower()

    # If the user inputs "star", import and display the Star drawing
    if user_input == "star":
        import Drawing1  
        Drawing1   

    # If the user inputs "yoda", import and display the Yoda drawing
    elif user_input == "yoda":
        import Drawing2  
        Drawing2   

    # If the user inputs "mario", import and display the Mario drawing
    elif user_input == "mario":
        import Drawing3  
        Drawing3   

    # If the user inputs "luigi", import and display the Luigi drawing
    elif user_input == "luigi":
        import Drawing4   
        Drawing4 

      # If the user types "exit", the loop will break and prompt to close the screen 
    elif user_input == "exit":
        print("Close the screen to exit...")
        break  # Exit the loop

    # If the input is not recognized, repeat the loop
    else:
        continue  # Go back to the start

    window.update()

    window.exitonclick()
