import turtle as t

window = t.Screen()  # Create a window for the turtle graphics
square = t.Turtle()   # Create a turtle named square

# Set tracer to False for immediate drawing
t.tracer(False)

"""DEFINE PIXART FUNCTION"""

def draw_square(x, y, fill_color):
    square.penup()  # Lift the pen to move without drawing
    square.fillcolor(fill_color)  # Set the fill color
    square.goto(x, y)  # Move to the (x, y) position
    square.pendown()  # Put the pen down to start drawing
    square.begin_fill()  # Start filling the shape
    for _ in range(4):  # Draw a square
        square.forward(20)  # Move forward by 20 units
        square.right(90)    # Turn right by 90 degrees
    square.end_fill()  # Finish filling the shape


"""PATTERN COLOR FOR YODA"""

yoda_pattern = [
    "0000000000000000000000000",
    "0111111111111111111111110",
    "0111111111100011111111110",
    "0111111110066600111111110",
    "0111111106656566011111110",
    "0111111096666666901110110",
    "0111000965656565690006010",
    "0110666666666666666665010",
    "0106556555666555666650110",
    "0110005101606101665501110",
    "0111110666666666660011110",
    "0111111066000666601111110",
    "0111111106666666011111110",
    "0111111110066660111111110",
    "0111111100A8778A011111110",
    "011111106AA8778AA01111110",
    "0111110770A8008A601111110",
    "0111111070A8778A011111110",
    "0111111070660066011111110",
    "0111111101001100111111110",
    "0111111111111111111111110",
    "0000000000000000000000000"
]

pattern_width = len(yoda_pattern[0])  # Get the width of the pattern
pattern_height = len(yoda_pattern)  # Get the height of the pattern

# Loop through each row of the pattern
for i, row in enumerate(yoda_pattern):
    # Loop through each character in the row
    for j, color_code in enumerate(row):
        x = (j - pattern_width / 2) * 20  # Calculate the x position
        y = (-i + pattern_height / 2) * 20  # Calculate the y position
        fill_color = "black"  # Default color for 0
        if color_code == "1":  # Color for 1
            fill_color = "white"
        elif color_code == "2":  # Color for 2
            fill_color = "tan"
        elif color_code == "3":  # Color for 3
            fill_color = "green"
        elif color_code == "6":  # Color for 6
            fill_color = "yellowgreen"
        elif color_code == "7":  # Color for 7
            fill_color = "sienna"
        elif color_code == "8":  # Color for 8
            fill_color = "tan"
        elif color_code == "9":  # Color for 9
            fill_color = "grey"
        elif color_code == "A":  # Color for A
            fill_color = "silver"

        # CALL THE PIXART FUNCTION
        draw_square(x, y, fill_color)

# Close the turtle graphics window when clicked
window.exitonclick()  # Wait for a click to exit
