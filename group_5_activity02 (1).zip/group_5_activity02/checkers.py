import turtle as t

# Constants for pixel size and grid dimensions
PIXEL_SIZE = 20
ROWS = 20
COLUMNS = 20

# Function to count total pixels
def count_pixels(rows, columns):
    return rows * columns

if __name__ == "__main__":
    # Test cases for pixel counting
    def test_count_pixels():
        assert count_pixels(20, 20) == 400
        assert count_pixels(10, 5) == 50
        assert count_pixels(0, 10) == 0 
        assert count_pixels(5, 0) == 0 

    test_count_pixels()  # Run tests

# Function to draw a single pixel
def draw_pixel(x, y, color):
    t.speed(0)  # Fastest drawing
    t.penup()  # Move without drawing
    t.goto(x, y)  # Position the turtle
    t.pendown()  # Start drawing
    t.fillcolor(color)  # Set fill color
    t.pencolor("black")  # Set outline color
    t.begin_fill()  # Start filling color
    for _ in range(4):  # Draw a square
        t.forward(PIXEL_SIZE)
        t.right(90)
    t.end_fill()  # Finish filling color
    t.penup()  # Lift pen

# Function to create pixel art
def pixel_art():
    t.speed(0)  # Fastest drawing
    t.pensize(0.2)  # Set pen size
    t.tracer(0)  # Disable screen updates for speed

    # Draw the grid of pixels
    for row in range(ROWS):
        for col in range(COLUMNS):
            # Calculate pixel position
            x = col * PIXEL_SIZE - (COLUMNS * PIXEL_SIZE) / 2
            y = (ROWS * PIXEL_SIZE) / 2 - row * PIXEL_SIZE

            # Alternate colors for checkerboard effect
            if (row + col) % 2 == 0:
                draw_pixel(x, y, "skyblue")
            else:
                draw_pixel(x, y, "midnightblue")

    t.done()  # Finish drawing

# Main to run the pixel art function
if __name__ == "__main__":
    pixel_art()  # Call pixel art function
    t.done()  # Keep window open
