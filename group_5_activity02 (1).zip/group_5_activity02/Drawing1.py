import turtle as t

window = t.Screen()  # Set up the screen for turtle graphics
square = t.Turtle()   # Create a turtle object named square

# Set tracer to False to display image immediately
t.tracer(False)

"""DEFINE THE PIXART FUNCTION"""
def draw_square(x, y, fill_color):
    """Draw a filled square (pixel) at (x, y) with the specified fill color."""
    square.penup()  # Lift the pen to move without drawing
    square.fillcolor(fill_color)  # Set the fill color
    square.goto(x, y)  # Move to the specified coordinates
    square.pendown()  # Lower the pen to start drawing
    square.begin_fill()  # Begin filling the shape
    for _ in range(4):  # Draw a square
        square.forward(20)  # Move forward by 20 units
        square.right(90)    # Turn right by 90 degrees
    square.end_fill()  # Complete filling the shape

"""PATTERN COLOR FOR STAR"""
star_pattern = [
    "00000000000000000000",
    "01111111111111111110",
    "01111111111111111110",
    "01111111100111111110",
    "01111111033011111110",
    "01111110333301111110",
    "01000000333300000010",
    "01033333333333333010",
    "01104333033033340110",
    "01110433033033401110",
    "01111043033034011110",
    "01111043333334011110",
    "01110433333333401110",
    "01110433333333401110",
    "01104334400443340110",
    "01104440011004440110",
    "01044001111110044010",
    "01000111111111100010",
    "01111111111111111110",
    "00000000000000000000"
]

pattern_width = len(star_pattern[0])  # Get the width of the pattern
pattern_height = len(star_pattern)  # Get the height of the pattern

# Loop through each row of the star pattern
for i, row in enumerate(star_pattern):
    # Loop through each character in the row
    for j, color_code in enumerate(row):
        x = (j - pattern_width / 2) * 20  # Calculate x coordinate
        y = (-i + pattern_height / 2) * 20  # Calculate y coordinate
        fill_color = "black"  # Default color for '0'
        
        # Set the fill color based on the color code
        if color_code == "1":
            fill_color = "white"
        elif color_code == "2":
            fill_color = "tan"
        elif color_code == "3":
            fill_color = "yellow"
        elif color_code == "4":
            fill_color = "orange"

        # CALL THE PIXART FUNCTION
        draw_square(x, y, fill_color)  # Draw the pixel

# Close the turtle graphics window when clicked
window.exitonclick()  # Wait for a click to exit the program
