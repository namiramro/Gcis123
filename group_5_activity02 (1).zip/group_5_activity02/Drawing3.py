import turtle as t

window = t.Screen()  # Create a window for turtle graphics
square = t.Turtle()   # Create a turtle object named square

# Set tracer to False to display the image immediately
t.tracer(False)

"""DEFINE PIXART FUNCTION"""

def draw_square(x, y, fill_color):
    square.penup()  # Lift the pen to move without drawing
    square.fillcolor(fill_color)  # Set the fill color for the square
    square.goto(x, y)  # Move to the specified (x, y) position
    square.pendown()  # Put the pen down to start drawing
    square.begin_fill()  # Start filling the shape
    for _ in range(4):  # Draw a square
        square.forward(20)  # Move forward by 20 units
        square.right(90)    # Turn right by 90 degrees
    square.end_fill()  # Finish filling the shape

"""PATTERN COLOR FOR MARIO"""

mario_pattern = [
    "00000000000000000000",
    "01111111111111111110",
    "01111112222221111110",
    "01111122222222211110",
    "01111177778781111110",
    "01111787888788811110",
    "01111787788878881110",
    "01111778888777711110",
    "01111118888888111110",
    "01111177277711111110",
    "01111777277277711110",
    "01117777222277771110",
    "01118872822827881110",
    "01118882222228881110",
    "01118822222222881110",
    "01111122211222111110",
    "01111777111177711110",
    "01117777111177771110",
    "01111111111111111110",
    "00000000000000000000"
]

pattern_width = len(mario_pattern[0])  # Get the width of the pattern
pattern_height = len(mario_pattern)     # Get the height of the pattern

# Loop through each row in the pattern
for i, row in enumerate(mario_pattern):
    # Loop through each character in the row
    for j, color_code in enumerate(row):
        x = (j - pattern_width / 2) * 20  # Calculate the x position for the square
        y = (-i + pattern_height / 2) * 20  # Calculate the y position for the square
        fill_color = "black"  # Default color for 0 (no color)
        if color_code == "1":  # Color for 1
            fill_color = "white"
        elif color_code == "2":  # Color for 2
            fill_color = "red"
        elif color_code == "7":  # Color for 7
            fill_color = "sienna"
        elif color_code == "8":  # Color for 8
            fill_color = "tan"

        # CALL THE PIXART FUNCTION
        draw_square(x, y, fill_color)  # Draw the square with the determined fill color

# Close the turtle graphics window when clicked
window.exitonclick()  # Wait for a click to exit the window
