import turtle as t

# Colour Bank 
x = -300 
y = 70

t.speed(0)  # Set turtle speed to the fastest
t.tracer(False)  # Turn off animation for immediate drawing

t.up()  # Lift the pen up so it doesn't draw when moving
t.goto(-300, 70)  # Move to starting position
t.down()  # Put the pen down to start drawing

"""DRAWING BLACK PIXEL"""

def black_pixel(side):
    t.pencolor("black")  # Set pen color to black
    t.fillcolor("black")  # Set fill color to black

    t.setheading(0)  # Face right
    
    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)

    t.end_fill()  # Finish filling the shape
    
    t.forward(side)  # Move forward for the next pixel

"""DRAWING WHITE PIXEL"""

def white_pixel(side):
    t.pencolor("white")  # Set pen color to white
    t.fillcolor("white")  # Set fill color to white

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

"""DRAWING RED PIXEL"""

def red_pixel(side):
    t.pencolor("red")  # Set pen color to red
    t.fillcolor("red")  # Set fill color to red

    t.setheading(0)  # Face right

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

"""DRAWING YELLOW PIXEL"""

def yellow_pixel(side):
    t.pencolor("yellow")  # Set pen color to yellow
    t.fillcolor("yellow")  # Set fill color to yellow

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

"""DRAWING ORANGE PIXEL"""

def orange_pixel(side):
    t.pencolor("orange")  # Set pen color to orange
    t.fillcolor("orange")  # Set fill color to orange

    t.setheading(0)  # Face right

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

"""DRAWING GREEN PIXEL"""

def green_pixel(side):
    t.pencolor("green")  # Set pen color to green
    t.fillcolor("green")  # Set fill color to green

    t.setheading(0)  # Face right

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

"""DRAWING LIGHT GREEN PIXEL"""

def lightgreen_pixel(side):
    t.pencolor("yellowgreen")  # Set pen color to light green
    t.fillcolor("yellowgreen")  # Set fill color to light green

    t.setheading(0)  # Face right

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

"""DRAWING BROWN PIXEL"""

def brown_pixel(side):
    t.pencolor("sienna")  # Set pen color to brown
    t.fillcolor("sienna")  # Set fill color to brown

    t.setheading(0)  # Face right

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

"""DRAWING LIGHT BROWN PIXEL"""

def lightbrown_pixel(side):
    t.pencolor("tan")  # Set pen color to light brown
    t.fillcolor("tan")  # Set fill color to light brown

    t.setheading(0)  # Face right

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape
    
"""DRAWING GRAY PIXEL"""

def gray_pixel(side):
    t.pencolor("gray")  # Set pen color to gray
    t.fillcolor("gray")  # Set fill color to gray

    t.setheading(0)  # Face right

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

"""DRAWING DARK GRAY PIXEL"""

def darkgray_pixel(side):
    t.pencolor("darkgray")  # Set pen color to dark gray
    t.fillcolor("darkgray")  # Set fill color to dark gray

    t.setheading(0)  # Face right

    t.begin_fill()  # Start filling the shape

    for x in range(4):  # Draw a square
        t.forward(side)
        t.right(90)
        
    t.forward(side)  # Move forward for the next pixel

    t.end_fill()  # Finish filling the shape

# Map color codes to their corresponding functions
colour_string = {
    "0": black_pixel,
    "1": white_pixel,
    "2": red_pixel,
    "3": yellow_pixel,
    "4": orange_pixel,
    "5": green_pixel,
    "6": lightgreen_pixel,
    "7": brown_pixel,
    "8": lightbrown_pixel,
    "9": gray_pixel,
    "A": darkgray_pixel,
}

'''
    This part checks if the user entered a valid string.
    If it is valid, it will draw the pixels using the color codes.
'''

def draw_string(size): # Parameter decides size of the pixel
    # Loop allows the user to be reprompted if the input is invalid

    while True:
        user_color = input("Enter a string: ").strip()  # Get user input

        def draw_next_rows(x):
            t.up()  # Lift the pen up
            next_row = t.ycor() - size  # Move to the next row
            t.goto(x, next_row)  # Go to the new position
            t.down()  # Put the pen down

        draw_next_rows(-290)  # Draw the first row

        # Makes sure that input cannot be empty while reprompting user.
        if not user_color:
            print("Input cannot be empty.")  # Print error message
            continue  # Start over if input is empty
        
        # This makes it so that every 20 characters in the string, the next row starts
        try:
            x = 0
            while x < len(user_color):  # Loop through the input string
                chunk = user_color[x:x+20]  # Get chunks of 20 characters

                for color in chunk:  # Loop through each color in the chunk
                    if color not in colour_string:  # Check if color is valid
                        raise ValueError(f"Invalid color: {color}")  # Raise error if invalid
                        
                    colour_string[color](size)  # Draw the pixel using the color function

                draw_next_rows(-300)  # Move down for the next row

                x += 20  # Move to the next chunk

            break  # Exit the loop if the input is valid
            
        except ValueError as ve:
            print(ve)  # Print the error message if an exception occurs

def main():
    draw_string(50)  # Call the draw_string function with pixel size 50
    input("Press Enter to Continue...")  # Wait for user input before closing

main()  # Run the main function
